getwd()
setwd("C:\\Users\\CYBORG\\Desktop\\IT24102862")
#Q1 a
#random variable X has binomial distribution with n=50 and p= 0.85
#Q1 b
dbinom(47,50,0.85)
#Q2 a
# Number of customer calls per hour
#Q2 b
#random variable X has binomial distribution with Lamda 12
#Q2 c
dpois(15,12)
